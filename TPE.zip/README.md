# Proyecto Biblioteca Publica - WEB 2 TPE

## Desarrolladores

Grandio Juan Manuel - Ciancio Aaron Gabriel. 

## Descripción

Este proyecto consiste en una base de datos para una biblioteca pública. El objetivo es gestionar los libros, usuarios y préstamos de manera eficiente. La base de datos está diseñada para facilitar la administración de los recursos de la biblioteca y las interacciones con los usuarios.

## Diagrama del Modelo de Datos

A continuación se muestra el diagrama del modelo de datos para la base de datos de la biblioteca pública.

![Diagrama](https://github.com/user-attachments/assets/1d5c3313-02df-410f-b82f-3b8e3d656770)

## Explicación del Dominio

El modelo de datos para la biblioteca pública incluye las siguientes entidades principales:

1) Prestamo: partimos de un prestamo otorgado por la bibliteca en el cual se relaciona con un libro y un usuario al cual se le otorga el mismo.
2) Usuario: se reflejan los datos identificatorios del usuario tales como nombre, apellido, direccion, etc.
3) Libros: Se almacena los datos relacionados al titulo,  autor, fecha de publicacion, editorial, genero y cantidad de copias disponibles.  

## Desplegar Sitio WEB 

Listo aqui los pasos a seguir para poder desplegar el sitio web:

1) Instalar XAMPP en la computadora local junto con PhpMyAdmin. 
2) Encender Apache y MySQL para utilizar la misma como servidor local.
3) Crear una base de datos en PhpMyAdmin. 
4) Importar desde la base de datos creadas, el archivo biblioteca.sql.
5) Navegar por la pagina WEB. 

## Informacion de Administrador

Para poder loguearse como administrador es necesario contar con la siguiente informacion:

1) Usuario: web2admin@gmail.com.
2) Password: 123456.






